This sample shows how invoke Aspose.Words to generate a Microsoft Word document when a user clicks a button or a link on a web page. The request to generate and the produced document are delivered using AJAX functionality in ASP.NET.

Requirements:

+ Visual Studio 2005

+ .NET Framework 2.0

+ ASP.NET AJAX 1.0 or later, can be download from http://www.microsoft.com/downloads/details.aspx?FamilyID=ca9d90fa-e8c9-42e3-aa19-08e2c027f5d6&displaylang=en
