' Copyright (c) 2001-2014 Aspose Pty Ltd. All Rights Reserved.
'
' This file is part of Aspose.Words. The source code in this file
' is only intended as a supplement to the documentation, and is provided
' "as is", without warranty of any kind, either expressed or implied.
'////////////////////////////////////////////////////////////////////////

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Net
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Animation
Imports System.Windows.Navigation
Imports System.Windows.Shapes

Namespace FirstFloor.Documents.Aspose
	Partial Public Class About
		Inherits Page
		Public Sub New()
			InitializeComponent()
		End Sub

		' Executes when the user navigates to this page.
		Protected Overrides Sub OnNavigatedTo(ByVal e As NavigationEventArgs)
		End Sub
	End Class
End Namespace